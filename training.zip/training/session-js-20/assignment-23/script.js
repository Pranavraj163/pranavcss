//1st question
let student1={
    name:'krishna',
    age:19,
    rollno:1524,
    branch:'cse',
    section:'d',
    contact:9242592424,
    email:'krishna123@gmail.com',
    cgpa:9.35
};

let bus={
    name:'rover',
    company:'eicher',
    cost:250000,
    capacity:50,
    max_speed:100,
    fuel:'diesel'
};

let employee={
    name:'ravi',
    eid:256896,
    position:'assistant manager',
    salary:50000,
    contact:9242592555,
    email:'kumarravi@gmail.com'
}

let mobile={
    model:'reno-8',
    brand:'oppo',
    os_version:11,
    camera_pixel:108,
    ram:128,
    rom:16,
    cost:28999
};



//second question
let student={
    name:'vamshi',
    rno:1414,
    marks:[90,95,88,75,98],
    address:{
        colony:'bhavani nagar',
        area:'kphb'
    },
    getAggregate : function(){
        let sum = 0;
        for(let v of this.marks) {
            sum = sum + v;
        }
        console.log(`aggregate of the marks is ${sum}`);
    }
};
// for(let v in student){
//     console.log(v,student[v]);
    
// }
student.getAggregate();


// third question
let product={
    no:96589632,
    name:'washing machine',
    model:'k23-458b',
    price: 29999,
    discountPrince: function(percentage){
        let new_price = this.price-(this.price*(percentage/100));
        console.log(`original price: ${this.price}`);
        
        console.log(`new price after ${percentage} percent discount is ${new_price}`);
    }
}
// 10% discount is applied and we will get the new price
product.discountPrince(10);

