
// 1st que
class Employee{
    constructor(name,age,contact,salary){
        this.name=name;
        this.age=age;
        
        this.contact=contact;
        this.salary=salary;   
    }
    // getSalary(){
    //     return this.salary;
    // } *normal method*
}
// using the prototype
Employee.prototype.getSalary=function(){
    return this.salary;
}
console.log("question 1");
let emp1 = new Employee('ramu',19,9999999999,50000);
let emp2 = new Employee('krishna',20,9245259245,60000);
let emp3 = new Employee('shiva',22,7032736920,100000);
let emp4 = new Employee('bharat',24,9000266594,25000);
let emp5 = new Employee('mani',23,8074592989,35000);

console.log(emp1.getSalary());
console.log(emp2.getSalary());
console.log(emp3.getSalary());
console.log(emp4.getSalary());
console.log(emp5.getSalary());

// 2nd question
class Product{
    constructor(brand,price,model){
        this.brand=brand;
        this.price=price;
        this.model=model;
    }
}
Product.prototype.getDiscountPrice=function(percentage){
        return this.price - (this.price * percentage /100);
}

let prod1 = new Product('usha',1250,'super cool');
let prod2 = new Product('campus',800,'ultra fit');
let prod3 = new Product('boat',1900,'rockerz 550');
let prod4 = new Product('IFB',25000,'super aque');
let prod5 = new Product('samsung',10100,'j2');

console.log("question 2");
console.log(prod1.getDiscountPrice(10));
console.log(prod2.getDiscountPrice(7));
console.log(prod3.getDiscountPrice(12));
console.log(prod4.getDiscountPrice(18));
console.log(prod5.getDiscountPrice(21));