console.log("three customers");
console.log("1st ordered biryani");
console.log("2nd ordered soup");
console.log("3rd ordered water");

setTimeout(() => {
    console.log("biryani received");
}, 10000);

setTimeout(() => {
    console.log("water received");
}, 1000);

setTimeout(() => {
    console.log("soup received");
}, 5000);
    