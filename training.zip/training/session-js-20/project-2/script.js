// hoisting(all declarations will move up)

// console.log(a);
// let a=10;

// a is there in the memory , but it is not initialized,, hence we will get the error of not initialized earlier
//TDZ temporal dead zone
// variable declared with let keyword wont be hoisted. but var keyword will be hoisted.


// test 1 is printed because already fucntion is in the main memory
function test1(){
    console.log('test1');
}


// hoisting doesnot take place in this case
let test2 = function(){
    console.log('test20');
     
}


// non primitive
let arr=[10,20,30,40,50,60];
console.log(arr.length);

for(let v of arr){
    console.log(v);
}

let student= {
    name:'vamshi',
    age:18,
    email:'vamshiraj@gmailcom',
    sno:44,
    address:{
        street:'kphb',
        code:1414,
        city:'hyderabad'
    },
    getStudentName:function(){
        console.log(this.name);
        // console.log(name); it will search for name outside of the student object.
    }
};


for(let v in student){
    console.log(v,':',student[v]);  
    // console.log(student[v])
}

// if we wirte student.v then there is nothing like v:"abdc" in the student. hence we will get error

// for(let v in student.address){
//     console.log(student.address[v]);  
// }
// student.getStudentName();

// let m = 200;

// function test11(){
//     m = 100;
// }
// console.log(m);
// test11();
// console.log(m);