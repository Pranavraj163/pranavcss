
let form = document.querySelector('form');
let sum = document.querySelector('.sum');
let minus = document.querySelector('.minus');
let into = document.querySelector('.into');
let divide = document.querySelector('.divide');
let result = document.querySelector('.result')
let modulo = document.querySelector('.modulo');

sum.addEventListener('click',(event)=>{
    event.preventDefault();
    let a = parseFloat(document.querySelector('#a').value);
    let b = parseFloat(document.querySelector('#b').value);
    result.innerHTML = `
        <h2>${a+b}</h2>
    `;
});

minus.addEventListener('click',(event)=>{
    event.preventDefault();
    let a = parseFloat(document.querySelector('#a').value);
    let b = parseFloat(document.querySelector('#b').value);
    result.innerHTML = `
        <h2>${a-b}</h2>
    `;
});

into.addEventListener('click',(event)=>{
    event.preventDefault();
    let a = parseFloat(document.querySelector('#a').value);
    let b = parseFloat(document.querySelector('#b').value);
    result.innerHTML = `
        <h2>${a*b}</h2>
    `;
});

divide.addEventListener('click',(event)=>{
    event.preventDefault();
    let a = parseFloat(document.querySelector('#a').value);
    let b = parseFloat(document.querySelector('#b').value);
    if(b==0){
        result.innerHTML = `
            <h2>Enter valid input</h2>
        `;
    }
    else{
        result.innerHTML = `
        <h2>${a/b}</h2>
    `;
    }
});

modulo.addEventListener('click',(event)=>{
    event.preventDefault();
    let a = parseFloat(document.querySelector('#a').value);
    let b = parseFloat(document.querySelector('#b').value);
    result.innerHTML = `
        <h2>${a%b}</h2>
    `;
});






























