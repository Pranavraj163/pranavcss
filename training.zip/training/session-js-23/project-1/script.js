class Person{
    //name;
    //age;
    //gender;
    // to initialize the object
    constructor(a,b,c){
        this.name=a;
        this.age=b;
        this.gender=c; 
    }

    getPersonDetails(){
        console.log(this.name,this.age,this.gender);
    }
}

let person1 = new Person('ravi',21,'male');
let person2 = new Person('vamshi',18,'male');
// console.log(person2);
// console.log(person1.getPersonDetails());

 
class Student{
    constructor(rollno,name,marks){
        this.rollno = rollno;
        this.name=name;
        this.marks=marks;
    }

    getAverage(){
        let sum = this.marks.reduce((acc,mark)=>acc+mark);
        let avg = sum/this.marks.length;
        return avg;
    }
}

let student1 = new Student(24,'vamshi',[100,90,80]);
console.log(student1);
console.log(student1.getAverage());