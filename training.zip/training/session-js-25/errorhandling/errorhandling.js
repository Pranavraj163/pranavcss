// what is error
// what happened when error is not handled
// program will be terminated abnormally when error is occured
// how to handle error
console.log('hello');
console.log('hi');

let emo={
    city:'hyd',
    //name:'ravi'
}
// // try catch
// try{

// }catch(error){

// }finally{

// }
try{
    // console.log(emo.name.length);
    if(emo.name===undefined){
        throw new Error("name property undefined");
    }
    else{
        console.log(emo.name);
    }
}catch(err){
    console.error("error is",err);
}
// console.error () can be used to get in the red color
console.log('hello');
console.log('hi');