import {a,b,emp} from '../module-1/script.js'
// it is exported by name so we have to import by name

console.log("a is ",a);
console.log("b is ",b);
console.log(emp);