let marks = [10, 20, 30];
// for (const element of marks) {
//     console.log(element);
// }
// unshift will return the length of the array (updated array)
// unshift -at the beginning
let l1 = marks.unshift(50, 60);
console.log(marks, l1);

// push at the end 
marks.push(100)
console.log(marks);

// position(index),no of elements to delete, values to insert.
marks.splice(3, 0, 111, 122, 133);
console.log(marks);

// remove element from the beginning
let rm1 = marks.shift();
console.log(rm1);
console.log(marks);

// remove element from the end
let rm2 = marks.pop();
console.log(rm2);
console.log(marks);
 
// from the middle 
let rm3 = marks.splice(2, 1);
console.log(rm3);
console.log(marks);

// updation of the value at particular place/s
let rm4 = marks.splice(1, 1, 2345);
console.log(rm4);
console.log(marks);