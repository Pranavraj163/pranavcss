// teranary operator
let a = 10;
a==10 ? console.log("true") : console.log("false") ;


// for(let start = 1; start<=2 ; start++){
//     console.log('abc');
//     console.log('def');
//     console.log('xyz');
//     console.log('mno');
// }

 
// let c=1;
// while(c<3){
//     console.log('abc');
//     console.log('def');
//     console.log('xyz');
//     console.log('mno');
//     c++;
// }


let m = 1;
do{
    console.log("executed");
    console.log("arey");
    m++;
}while(m<=3);



//functions
function addition(a,b){
    let sum = a+b;
    return sum;
}

console.log(addition(10,20))
console.log(addition(105,256))

function bigNo(fn,sn){
    if(fn>sn){
        return "first no is big";
    }else if (fn==sn){
        return "both are equal";
    }else{
        return "second number is bigger";
    }
}

console.log(bigNo(100,20))