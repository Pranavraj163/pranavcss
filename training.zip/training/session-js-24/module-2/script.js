// to get content form module-1

// we can use any name since it is default export in the module1 js file
// if it is named export then we will have to use name convention
import x from '../module-1/script.js'

console.log(x);
console.log(x.emp);
console.log(x.emp.name);  
// as it is a default export in module-1
// we can use any name while importing the data 