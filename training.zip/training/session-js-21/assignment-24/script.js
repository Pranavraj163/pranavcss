// sum of elements of array
let arr=[10,22,23,60,90,100];
let sum = arr.reduce((acc,element)=> acc+element);
console.log(`sum of elements : ${sum}`);

// 2nd
let a = [1,2,3,4];
let b = a.map((element,i)=>element+(i+1)*10);
// i refers to index value
console.log(b);


let marks=[
    { name:"ravi", marks :{ maths: 89, physics : 70 , chemistry :88}},
    { name:"bhanu", marks :{ maths: 98, physics : 50 , chemistry :68}},
    { name:"kiran", marks :{ maths: 50, physics : 82 , chemistry :94}},
];

let high_math = marks.reduce((one,two)=> one.marks['maths'] < two.marks['maths'] ? two:one).name;
console.log(`highest in maths : ${high_math}`);

let high_phy = marks.reduce((one,two)=> one.marks['physics'] < two.marks['physics'] ? two:one).name;
console.log(`highest in maths : ${high_phy}`);

let high_chem = marks.reduce((one,two)=> one.marks['chemistry'] < two.marks['chemistry'] ? two:one).name;
console.log(`highest in maths : ${high_chem}`);

