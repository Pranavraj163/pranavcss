// meeting freind
function meetingFriend(frndAvailability) {
    return new Promise((resolve, reject) => {
        console.log("going to meet friend");
        setTimeout(() => {
            if (frndAvailability) resolve("met friend");
            reject("could not meet friend");
        }, 5000);
    })
}
 
// ordering food
function ordeingFood(deliveryBoyAvailability) {
    return new Promise((resolve, reject) => {
        console.log("going to order food");
        setTimeout(() => {
            if (deliveryBoyAvailability) resolve("got food");
            reject("did not got food");
        }, 5000);
    })
}

meetingFriend(true)
    .then(res => {
        // res means some result 
        console.log(res);
        return ordeingFood(true);
    })// here second then is used since we have returned another promise
    .then(res => {
        console.log(res);
    })
    .catch(err => console.log(err));

console.log("some \nstatement");