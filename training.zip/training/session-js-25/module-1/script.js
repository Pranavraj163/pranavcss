let a=10;
let b = 20;
let emp = {
    name:'ravi',
    id:23012
}
// export default {a,b};
export{a,b,emp}
// named export