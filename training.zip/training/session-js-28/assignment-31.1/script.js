function myPromise(promiseStatus){
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            if(promiseStatus) resolve("promise fullfilled!");
            reject("sorry promise not fullfilled..")
        }, 5000);
    })
}

myPromise(true)
.then(res=>console.log(res))
.catch(err=>console.log(err))
