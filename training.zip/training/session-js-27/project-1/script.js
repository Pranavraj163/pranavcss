// synchronuous 1 2 3 
// asynchronous 1 3 2 (exection order)

// 1 code before time consuming task
console.log("first");
// 2 time consuming task
// timer fucntions
setTimeout(()=>{
    console.log("time consuming");
},2000)
// this line will be executed after 2000 milli seconds


// promises



// 3 code after time consuming task
console.log("last");