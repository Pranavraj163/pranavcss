// unpacking an array
let ar=[10,20,30];
let [x,,z] = ar;
console.log(x,z);

// unpacking object
let emp={
    name:'ravi',
    age:20,
    address:{
        city:'hyd'
    }
}
let {age,name,address:{city}}=emp;
// nested object city 
console.log(age,name);
console.log(city);


let {a,b,c}=emp;
console.log(a,b,c);
// we have to use the name convention
