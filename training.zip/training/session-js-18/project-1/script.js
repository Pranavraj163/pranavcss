let a = 10;
let b = 14;

if(a>b){
    console.log('a is big');
}else if (a===b){
    console.log('both are equal');
}else{
    console.log('b is big');
} 

let x = 12;
if(x>18){
    console.log('age is greater than 18');
}else{
    console.log('age is less than 18');
}


let choice = 3;
let m = 10;
let n = 20; 
 
switch(choice){
    case 1: console.log('sum :',m + n);
            break;
    case 2: console.log('diff :',m - n);
            break;
    case 3: console.log('prod :',m * n);
            break;
    case 4: console.log('divide:',m / n);
            break;
    case 5: console.log('remainder :',m % n);
            break;
    default: console.log('enter right choice');
}

for(let start = 1;start<=5;start++){
    console.log("hello");
    console.log("hi");
}

function test(a,b){
    console.log(a,b);
    console.log(`sum = ${a+b}`);
}
test(100,205)
// lowercamelcase
// priceOfProduct

// upper camel case
// PriceOfProduct