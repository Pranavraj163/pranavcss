// callback function-> fucntion which can be sent as argument to another function
 
let marks = [10,20,30,40,50,60,70]
// let result1 = marks.filter(function(element){
//     return element<50;
// })
console.log(marks);
let result1 = marks.filter((element)=>element<50)
let result2 = marks.filter((element)=>element>30 && element<80)
let resutltt = marks.filter((element)=>element>50);

console.log(result1); 
console.log(result2);
console.log(resutltt);

// map(modification)
// to change the data in simple terms
let result3 = marks.map((elements)=>elements+10)
console.log(result3);
 
let result4 = marks.map((element)=>{
    if(element<50) return element+20;
    else return element+10;
})
console.log(result4);

// foreach(iteration) explicitly for iteration only speciality -> element and index both will be iterated
marks.forEach((element,index)=>{
    console.log(element,index);
})

// find, it will return element if element is found 
let result= marks.find(el=>el===40)
console.log(result);

// findIndex , -1 if element is not found
let index = marks.findIndex(el => el ===40)
console.log(index);

// reduce (to reduce based on the given condition )
// accumulator stores the result of previous operation
let sum = marks.reduce((acc,element)=> acc+element);
console.log(sum);
let small = marks.reduce((acc,element)=>acc<element?acc:element);
console.log(small);











