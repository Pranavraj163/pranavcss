let emp = {
    name : 'ravi',
    age : 20
}
// methods to copy non primitives (or) duplicating the non primintives
// let empCopy = Object.assign({},emp);


let empCopy = {...emp}

 
// console.log(emp);
// console.log(empCopy);

empCopy.name = 'rajesh';
console.log(emp);
console.log(empCopy);

// primitives are immutable
// non-primitives are mutable


// for nested object we cannot use the assign method or spread operator{...emp}
// because the non primitives present in the both the objects will be pointing to the same .