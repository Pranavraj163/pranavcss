//dynamically typed language

let a;
console.log('value of a is ',a);
console.log('datatype of a is',typeof a);

a=10;
console.log('value of a is ',a);
console.log('datatype of a is',typeof a);

a='hello';
console.log('value of a is ',a);
console.log('datatype of a is',typeof a);

a=true;
console.log('value of a is ',a); 
console.log('datatype of a is',typeof a);

// console.log("hello")


//array
let skills = ['js','react','css'];
let marks = [90,89,100];

// object
let person = {
    pid: 100,
    name:'ravi',
    age:25,
    city:'hyd'

}
console.log(person);
//fucntion
function test(a,b){
// body of the fucntion

}







