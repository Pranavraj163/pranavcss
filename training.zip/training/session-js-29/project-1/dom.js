console.log(document)
// access head and body
console.log(document.head)
console.log(document.body)

// accessing elements
let heading1 = document.querySelector('#heading1')
console.log(heading1)
let heading2 = document.querySelector('.heading2')

let button = document.querySelector('.button1')
let button2 = document.querySelector('.button2')
// event handler
// button.addEventListener('click',()=>{
    
// })
let parent = document.querySelector('.parent')

let p = document.querySelector('.p')
 
button.addEventListener('click',()=>{
    // change content dynamically
    heading1.textContent = 'Changed on clicking';
    // changing the styles dynamically
    heading1.style.color='red';
    heading1.style.backgroundColor='yellow';
    heading1.style.fontSize='50px';
    // create element to add into DOM
    let h2 = document.createElement('h2');
    h2.textContent = 'this is the new one';
    h2.style.color = 'blue';
    parent.appendChild(h2);
})

button2.addEventListener('click',()=>{
    // reomveing the element itself
    heading2.remove();
    // removing child
    document.body.removeChild(p);
})
