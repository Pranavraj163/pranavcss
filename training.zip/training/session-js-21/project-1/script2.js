let users =[{id:1,name:'ravi'},{id:2,name:'krishna'}];
// for ( element of users) {
//     // console.log(element.name);
// }
users.unshift({id:3,name:'raju'})

console.log(users[0]);
users.push({id:4,name:'raj'})
console.log(users[users.length-1]);
users.splice(2,0,{id:6,name:'varun'});
console.log(users[2]);  
// if u use clg(users) then
// it will show the latest model after final changes..