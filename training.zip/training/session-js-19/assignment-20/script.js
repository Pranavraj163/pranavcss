// arithmetic operations
let a=10;
let b=20;
console.log("addition : ",a+b);
console.log("subtraction : ",a-b);
console.log("multiplication : ",a*b);
console.log("division : ",a/b);
console.log("remainder(modulo 10%20) : ",a%b);



// unary increment and decrement operators
let i=1;
// it will be printing the value of i uptill the value of i is less than 5 and then stop when it reaches 5
// ++ is the increment operator
while(i<5){
    console.log(i);
    i++;
}

let j=5;
// it will be printing the value of i uptill the value of i is greater than or equal to 1
// and then stop when it reaches 0 -- is the decrement operator
while(j>=1){
    console.log(j);
    j--;
}

// comparision operators
let x = 10;
let y = 20;
console.log(x>y) //checks whether x is greater than y
console.log(x>=y) //checks whether x is greater than or equal to  y
console.log(x<y) //checks whether x is less than y
console.log(x<=y) //checks whether x is less than or equal to y
console.log(x==y) //checks whether x is equal to y
console.log(x!=y) //checks whether x is not equal to y

console.log("4")
let m = 10;
let n = '10';
console.log(m==n);
// it will check only the value stored in the variable
console.log(m===n);
// it will also check the data types and the value stored in the particular variables