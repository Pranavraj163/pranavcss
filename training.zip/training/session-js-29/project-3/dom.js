let  parent = document.querySelector('.parent')
// getting data
function getPostData(){
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then((res)=>res.json())
    .then(posts => {
        posts.forEach(postsObj=>{
            parent.innerHTML += `
            <div class="col g-3">
                <div class="card card-body text-center h-100">
                    <h3>${postsObj.userId}</h3>
                    <h3>${postsObj.id}</h3>
                    <h3>${postsObj.title}</h3>
                </div>
            </div>
            `
        })
    })
    .catch(err=>console.log(err));
}

getPostData(); 