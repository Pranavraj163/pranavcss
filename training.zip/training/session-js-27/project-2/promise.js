let condition = 1;
function meetFriendPromise() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition === 1) resolve("hello how are you");
            else reject("could not meet you");
        }, 7000);
    })
}
meetFriendPromise()
    .then((resolve) => {
        console.log(resolve);
    })
    .catch((reject) => {
        console.log(reject); 
    })  

function meetFriendPromise2() {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (condition === 1) resolve(console.log("hello how are you 2"));
                else reject(console.log("could not meet you 2" ));
            }, 3000);
        })
    }

meetFriendPromise2()    
.then()
.catch()