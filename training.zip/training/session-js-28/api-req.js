// making api reqest
// making the http get request
function getData(){
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res=>res.json())
    .then(posts=>console.log(posts))
    .catch(err=>console.log(err))
}
//getData();

console.log('first');

function getProd(){
    fetch('https://fakestoreapi.com/products')
    .then(res=>res.json())
    .then(prod=>console.table(prod))
    .catch(err => console.log(err));
}
getProd();
 
  