let users=[
    {id:1,name:'ravi',age:19,salary:20000},
    {id:2,name:'manasa',age:23,salary:40000},
    {id:3,name:'bhanu',age:21,salary:10000},
    {id:4,name:'vikas',age:32,salary:50000}
]
let user1 = users.filter(userobj=>userobj.age<22)
console.log(user1);

// map
let user2 = users.map(userobj=>{
    userobj.salary+=5000; 
    return userobj;
})
console.log(user2);


let lowest = users.reduce((acc,userobj)=>acc.salary<userobj.salary?acc:userobj);
console.log(lowest);
 