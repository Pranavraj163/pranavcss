let form = document.querySelector('form')
let input1 = document.querySelector('#username')
let input2 = document.querySelector('#date')
let submitbtn = document.querySelector('.submit-btn')
let tbody = document.querySelector('tbody')

// adding the event listener
form.addEventListener('submit',(event)=>{
    // to stop the refresh of the page
    event.preventDefault();
    let username = input1.value;
    let dob = input2.value;
    

    //displaying them
    // let usernameh2 = document.createElement('h2')
    // usernameh2.textContent = username;
    // usernameh2.setAttribute('class','text-center');
    // let dobh2 = document.createElement('h2')
    // dobh2.textContent = dob;
    // dobh2.setAttribute('class','text-center');
    // document.body.appendChild(usernameh2);
    // document.body.appendChild(dobh2);
    tbody.innerHTML += `<tr>
        <td>${username}</td>
        <td>${dob}</td>
    </tr>`;

}) 