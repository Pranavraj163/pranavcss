let test2= function(a,b){
    console.log(`a is ${a}`);
    console.log(`b is ${b}`);   
}
test2(100,200);
// arrow fucntion

// simply fucntion expression

// no need or return keyword

let sum2  = (a,b)=>   a+b;

let k =sum2(20,15);

console.log(k);

 