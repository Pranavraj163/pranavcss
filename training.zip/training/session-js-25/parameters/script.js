let findSum = function(a,b){
    return a+b;
}
console.log(findSum(10 ,20));

// let findSum2 = fucntion(){} is also same as
// default values are set 
function findSum2(a=0,b=0){
    console.log(a);
    console.log(b);
    return a+b;
}
console.log("sum is ", findSum2(20));


// rest parameters
function findSum3(...a){
    // return a+b;
    // console.log(a);
    return a.reduce((acc,element)=>acc+element);
}
console.log(findSum3(10,20,30,40));
// console.log(findSum3(10,20,30,40));