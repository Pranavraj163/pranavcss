// arithmetic
let a=10;
let b = 20;
console.log("sum is ",a+b);
console.log("diff is ",a-b);
console.log("prod is ",a*b);
console.log("div is ",a/b);
console.log("mod is ",a%b);


// asiignment
let k = 100;

// equal to operator
console.log(a==b);

let p = 121;
let q = '121';

console.log(typeof p);
console.log(typeof q); 
// == equal to
// === strict equal to
console.log(p==q);
console.log(p===q);

// comparision >=  > <=  < !=  !==
let m = 10;
let n = 20;
console.log(n>m);



// logical && || !
