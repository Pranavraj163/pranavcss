console.log('first');
console.log('second');
console.log('third');
// in inspect go to sources and set the break points to debug the program