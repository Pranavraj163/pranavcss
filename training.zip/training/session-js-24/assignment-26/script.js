 // question 1
 let str1 = 'aaaabbababababbbbabababaaaa';
 let count1 =  0;
 let count2 = 0;
 console.log(str1);
 // since it is considered as a array of characters we are using the for of loop
 for (let element of str1) {
        if(element == 'a') count1++;
        else count2++;
 }
 console.log(`no of a\'s: ${count1}`);
 console.log(`no of b\'s: ${count2}`);

 // question 2
 let noOFWords = function(str){
        str = str.split(' ');
        //console.log(str);
        return str.length;
 }
 let str2 = 'how are you all i am vamshi raj';
 console.log(str2);
 console.log(`no of words in the string is ${noOFWords(str2)}`);