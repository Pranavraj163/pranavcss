let person ={
    name : 'vamshi',
    rollno: 100,
    pid: 211
}
console.log(person);

let personJson = JSON.stringify(person);
console.log(personJson);


// parse method will take the entire string
//*******************************/
let pjs = JSON.parse('{"name":"vamshi","rollno":100,"pid":211}')
console.log(pjs);  