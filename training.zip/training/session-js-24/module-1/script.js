let a = 100;
let b = 'hello';

let emp={
    name : 'ravi',
    id : 100
}
export default {a,b,emp};  
// export default {a,b};  

// we can export only single quantity 
// hence we will pack the items into array or objects 