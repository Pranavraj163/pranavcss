let obj = {
    name : "vamshi",
    age : 21,
    branch: "cse",
    marks : [11,12,13,14,15]
}
// shallow copy
let objCopy = {...obj};

obj.age=44;
console.log(objCopy);


// deep copy
let objDeep = JSON.parse(JSON.stringify(obj));
obj.age=66;
console.log(objDeep);
// changes made are not reflected to both the copies

// destructuring deeply nested object
let obj2 = {
    name : "krishna",
    age : 21,
    address: {
        city: "hyderabad",
        state: "telangana"
    }
}

let {name,age,address:{city,state}} = obj2;
console.log(name,age,city,state);

// ⁠Write a function which can receive any no of args and return small one

function smallOne(...args){
    let small = args.reduce((acc,next)=>acc<next?acc:next)
    return small;
}

let s = smallOne(10,20,30,40,50,60);
console.log(s);