// declaring the array
let a = [2,3,5,6,9,18,25,31,60,98,100]
// finding sum of elements
let sum = 0;
for(let v of a){
    sum = sum + v;
}
console.log('sum of the array elements is',sum);
console.log('even numbers of array:');
for(let v of a){
    if(v % 2==0) console.log(v);
}
// prime numbers in array
function is_prime(a){
    for(let i=2;i<=a/2;i++){
        if(a%i==0) return 0;
    }
    return 1;
}
console.log('prime numbers in array:');

for(let v of a){
    if(is_prime(v)==1) console.log(v);
    
}