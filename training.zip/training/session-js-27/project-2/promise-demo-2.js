let rank = 1;
function gettingFirstRank() {
    return new Promise((resolve, reject) => {
        console.log("i am trying for the first rank");
        setTimeout(() => {
            
            if (rank === 1) resolve("you got first rank");
            reject("you did not get 1st rank");
        }, 2000); //  here 10s represents the time taken to complete the evaluation of the results
    })
}   

gettingFirstRank()
    .then((res) => {
        console.log(res);
    })
    .catch((err) => {
        console.log(err);
    })
// console.log("first");