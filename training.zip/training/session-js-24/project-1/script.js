 let quote = 'welcome to javascript';
 // length of string
 console.log(quote.length);
// substring start->1 end at -> 3
 console.log(quote.substring(1,4));

 console.log(quote.charAt(1));
 console.log(quote[6]);

// get index of charecter
console.log(quote.indexOf('java'));
//stops after finding the first match
//
 console.log(quote.toUpperCase()); 

 console.log(quote.toLowerCase());

// joining the strings
 let str1 = 'hello';
 let str2 = 'man'; 
 console.log(str1+ str2);;
 console.log(str1.concat(str2));

// split the string to array
 console.log(quote.split('')); 