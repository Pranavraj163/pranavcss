let parent = document.querySelector('.parent')


function getData(){
    fetch(' https://jsonplaceholder.typicode.com/todos')
    .then(res=>res.json())
    .then(res=>{
        // in the console
        console.log("in the table format");
        console.table(res)

        // on the web page
        res.forEach(a=>{
            parent.innerHTML+=`
            <div class="col g-3">
            <div class="card card-body text-center h-100">
                <p>${a.userId}</p>
                <p>${a.id}</p>
                <p>${a.title}</p>
                <p>${a.completed}</p>
            </div>    
            </div>
        `
        })
    })
    .catch(err=>console.log(err))
}

getData()