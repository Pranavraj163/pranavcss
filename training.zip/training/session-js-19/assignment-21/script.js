//1
let a=10;
let b=20;
if(a>b){
    console.log('a is greater than b');
}else if(a==b){
    console.log('a and b are equal');
}else{
    console.log('b is greater than a');
}

//2
let c=30;
if(a>b){
    if(a>c){
        console.log('a is largest');
    }
    else{
        console.log('c is largest');
    }
}
else{
    if(b>c){
        console.log('b is largest');
    }
    else{
        console.log('c is largest');
    }
}
//3
function factors(a){
    for(let i=1;i<=a;i++){
        if(a%i==0) console.log(i);
    }
}
console.log('factors of 12' )
factors(12);
// prime or not
function prime_or_not(a){
    let count=0;
    for(let i=1;i<=a;i++){
        if(a%i==0) count++;
    }
    if(count==2) console.log('it is a prime number');
    else console.log('it is not a prime number');
}
console.log('31')
prime_or_not(31);
// even factors of given number
function even_factors(a){
    for(let i=1;i<=a;i++){
        if(a%i==0 && i%2==0) console.log(i);
    }
}
console.log('even factors os 30')
even_factors(30);
// sum of digits
function sum_of_digits(a){
    if(a<0) a = a * -1;
    let sum=0;
    while(a>0){
        sum = sum + a%10;
        a = Math.floor(a/10);
        //console.log(a);
    }
    console.log(sum);
}
console.log('sum of digits of -1234')
sum_of_digits(-1234);