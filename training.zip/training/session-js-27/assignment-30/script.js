function downloadFile(internetPresence){
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            if(internetPresence){
                resolve("downloading the file");
            }
            else{
                reject("unable to download the file");
            }
        }, 3000);
    })
}

downloadFile(true)
.then(res=>{
    console.log(res);
})
.catch(err=>{
    console.log(err);
})


function payment(amount){
    let balance = 1000;
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            if(amount<balance){
                resolve("payment done!")
            }
            else{
                reject("insufficient balance!")
            }
        }, 5000);
    })
}

payment(1200)
.then(res=>{
    console.log(res);
})
.catch(err=>{
    console.log(err);
})

function uploadFile(internetPresence){
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            if(internetPresence){
                resolve("uploading the file");
            }
            else{
                reject("unable to upload the file");
            }
        }, 7000);
    })
}

uploadFile(true)
.then(res=>{
    console.log(res);
})
.catch(err=>{
    console.log(err);
})