let person={
    id:1,
    name:'ravi'
};
// console.log(person.name);
for (let key in person) {
    console.log(person[key]);
}

// insertion
person.city='hyderabad';
person.mobile=9999999;
console.log(person);

// deletion
// delete keyword
delete person.name;
console.log(person);
// updation 
person.city='chennai';
console.log(person);
 console.log('\n');
// complex object
let student={
    rno:100, 
    firstName:'kiran',
    secondName:'babu',
    isQualified:true,
    skills:['css','js','react'],
    marks:[{maths:99},{science:99},{social:67}],
    address:{
        city:'hyd',
        street:'kphb'
    },
    // getName:function(){
    getName(){
        return this.firstName+" "+this.secondName;
    }
}
console.log(student.getName());
// console.log("\n");
for(let v in student.address){
    console.log(student.address[v]);
}

// for(let v in student)
    // console.log(student[v]);