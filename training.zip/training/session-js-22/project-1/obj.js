let emp ={
    id:1,
    name:'vamshi',
    age:19,
    salary:20000,
    city:'hyd'
}
// get all keys
let keys = Object.keys(emp);
console.log(keys);
// get all values
let v = Object.values(emp);
console.log(v);

// Object.freeze(emp) will be used to freeze the object no modifications  will be allowed
class Employee{
    eno;
    ename;
    salary;
}

let emp1 = new Employee();
