import employees from '../module-1/script.js'
// console.log(employees);
console.log('employees from hyderabad');
let arr = employees.filter(x => x.address.city=="hyderabad").map(x => x.name);
console.log(arr);
console.log('\n');
console.log("employees having age b/w 40 and 50");
for (let member of employees) {
    if(member.age>40 && member.age<50) console.log(member.name,member.address);
}
console.log('employees not from hyderabad');
arr = employees.filter(x=>x.address.city!="hyderabad").map(x=>x.name);
console.log(arr);
console.log('\n');
// .includes helps identify whether the element is present or not
arr = employees.filter(x => x.skills.includes("reactjs")).map(x => x.name);
console.log(arr);

